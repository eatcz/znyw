export const GENDER = [
    {
        id: 0,
        label:'男'
    },
    {
        id: 1,
        label:'女'
    }
]