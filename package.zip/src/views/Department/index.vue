<template>
    <div class="user-wrapper">
        <div class="title-wrapper">
            <h3 class="title">部门列表</h3>
            <div class="button-wrapper">
                <!-- <div class="button" v-for="item in fnList" :key="item.id"> -->
                <div class="button" @click="handleAdd">
                    <img :src="getImageUrl('users')" alt="">
                    <span>新增</span>
                </div>
                <div class="button">
                    <img :src="getImageUrl('import')" alt="">
                    <span>导入</span>
                </div>
            </div>
        </div>

        <div class="table-wrapper">
            <el-tree style="max-width: 600px" :props="props" :data="treeData" node-key="id"
                @updateKeyChildren="handleUpdateChildren" lazy show-checkbox @check-change="handleCheckChange" />
        </div>
    </div>
    <Information ref="infoRef" />

    <Form ref="formRef" />
</template>

<script setup lang='ts'>
import { onMounted, ref } from 'vue'
import { getImageUrl } from '../../utils'
import { getDepartment } from '../../api/department'
import Form from './components/Form.vue'
import { ElMessage, ElMessageBox, } from 'element-plus'
import Information from './components/Information.vue'

interface Tree {
    name: string
}

const props = {
    label: 'name',
    children: 'zones',
}

onMounted(() => {
    getDepartmentList()
})

const treeData = ref<any>([])

const getDepartmentList = async () => {
    const res = await getDepartment() as any
    treeData.value = res.content
}

const formRef = ref<null | any>(null)
const infoRef = ref<null | any>(null)


const handleCheckChange = (
    data: Tree,
    checked: boolean,
    indeterminate: boolean
) => {
    console.log(data, checked, indeterminate)
}

// 更新树节点数据
const handleUpdateChildren = (key, data) => {
    console.log(key, data)
}


// 新增
const handleAdd = () => {
    formRef.value.handleShow()
}
</script>

<style scoped lang='scss'>
.user-wrapper {

    .title-wrapper {
        display: flex;
        justify-content: space-between;
        padding-bottom: 7px;
        border-bottom: 1px solid #0e9cff;

        .title {
            font-size: 18px;
            color: #fff;
            font-weight: bold;
        }

        .button-wrapper {
            display: flex;
            gap: 12px;

            .button {
                cursor: pointer;
                display: flex;
                justify-content: center;
                align-items: center;
                width: 140px;
                border-radius: 4px;
                opacity: 1;
                padding: 3.5px 6px;
                gap: 4px;
                background: rgba(47, 109, 255, 0.2);
                color: #fff;

                box-sizing: border-box;
                border: 1px solid #2F6DFF;
            }
        }
    }

    .pagination {
        position: absolute;
        right: 16px;
        bottom: 16px;

    }

}


.btn {
    cursor: pointer;
    width: 120px;
    height: 30px;
    line-height: 30px;
    text-align: center;
    background: rgba(47, 109, 255, 0.2);
    border-radius: 4px;
    opacity: 1;
    box-sizing: border-box;
    border: 1px solid #2F6DFF;
    color: #fff;
}

.table-row-bg {
    background-color: #000;
}
</style>

<style scoped>
:deep(.el-table td.el-table__cell) {
    border-bottom: none;
}

:deep(.el-table th.el-table__cell) {
    background: none;
}

:deep(.is-leaf) {
    border-bottom: none !important;
}

:deep(.el-table::before) {
    height: 0px;
}

/* 
:deep(.el-table__row:hover) {
    background-color: red !important;
} */

:deep(.el-pager li) {
    color: #fff;
    background: rgba(22, 92, 255, 0.4) !important;
}

:deep(.btn-prev) {
    color: #fff;
    background: rgba(22, 92, 255, 0.4) !important;
}

:deep(.btn-next) {
    color: #fff;
    background: rgba(22, 92, 255, 0.4) !important;
}

:deep(.el-dialog) {
    /* background: rgba(47, 109, 255, 0.2) !important; */
    color: #fff;
    box-sizing: border-box;
    border: 1px solid #2F6DFF;
    opacity: 1 !important;
}

:deep(.el-message-box__title) {
    text-align: center !important;
}
</style>