declare module 'vue-baidu-map-3x' {
  const VueBaiduMap: any;
  export default VueBaiduMap;
}
