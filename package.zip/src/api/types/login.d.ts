export interface Code {
    img: string
    uuid:string
}

export interface Login {
    code: string
    username: string
    password: string
    uuid:string
}